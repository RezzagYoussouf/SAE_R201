public class TestOperation {
    public static void main(String[] args) {
        try {

            Expression deux = new Nombre(0);
            Expression trois = new Nombre(0);
            Expression dixSept = new Nombre(17);

            Expression soustraction = new Soustraction(dixSept, deux);
            Expression addition = new Addition(deux, trois);

            try {
                Expression division = new Division(soustraction, addition);
                System.out.println(division + " = " + division.valeur());
            } catch (ArithmeticException e) {
                System.out.println("Erreur: On ne peut diviser par 0");
            }

        } catch (ArithmeticException e) {
            System.out.println("Erreur: " + e.toString());
        }
    }
}


