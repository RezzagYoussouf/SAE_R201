public abstract class Expression {
    public abstract double valeur();
    public abstract String toString();
}