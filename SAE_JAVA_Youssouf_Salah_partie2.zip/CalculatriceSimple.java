public class CalculatriceSimple {
    public static void main(String[] args) {
        try {
            Nombre six = new Nombre(6);
            Nombre dix = new Nombre(10);

            Operation addition = new Addition(dix, six);
            System.out.println(addition + " = " + addition.valeur());

            Operation soustraction = new Soustraction(dix, six);
            System.out.println(soustraction + " = " + soustraction.valeur());

            Operation multiplication = new Multiplication(dix, six);
            System.out.println(multiplication + " = " + multiplication.valeur());

            Operation division = new Division(dix, six);
            System.out.println(division + " = " + division.valeur());

            try {
                Nombre zero = new Nombre(0);
                Operation divisionByZero = new Division(dix, zero);
                System.out.println(divisionByZero + " = " + divisionByZero.valeur());
            } catch (ArithmeticException e) {
                System.out.println("Erreur: On ne peut diviser par 0");
            }

        } catch (IllegalArgumentException e) {
            System.out.println("Erreur: " + e.toString());
        }
    }
}
