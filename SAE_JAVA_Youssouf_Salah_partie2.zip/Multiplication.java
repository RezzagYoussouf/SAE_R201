class Multiplication extends Operation {
    public Multiplication(Expression operande1, Expression operande2) {
        super(operande1, operande2);
    }

    @Override
    public double valeur() {
        return super.getOperande1().valeur() * super.getOperande2().valeur();
    }


    public String toString() {
        return super.getOperande1().valeur()+"*"+super.getOperande2().valeur();
    }
}
